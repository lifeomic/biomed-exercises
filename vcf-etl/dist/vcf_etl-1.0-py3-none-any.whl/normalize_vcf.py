import logging


def normalize_vcf(vcf_in: str, vcf_out: str):
    print("Hello World")
    return "Hello World"
